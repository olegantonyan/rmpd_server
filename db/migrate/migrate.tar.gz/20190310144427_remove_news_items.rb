class RemoveNewsItems < ActiveRecord::Migration[5.2]
  def up
    remove_column :users, :allow_notifications
    drop_table :news_items
  end

  def down
    add_column :users, :allow_notifications, :boolean, default: false, null: false
    create_table :news_items do |t|
      t.text :body, null: false, limit: 6000
      t.timestamps null: false
    end
  end
end
