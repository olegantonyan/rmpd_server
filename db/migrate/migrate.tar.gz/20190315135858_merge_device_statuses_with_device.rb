class MergeDeviceStatusesWithDevice < ActiveRecord::Migration[6.0]
  def change
    add_column :devices, :online, :boolean, null: false, default: false
    add_column :devices, :poweredon_at, :datetime
    add_column :devices, :now_playing, :string, null: false, default: ''
    add_column :devices, :devicetime, :datetime
    add_column :devices, :free_space, :bigint, null: false, default: 0

    reversible do |dir|
      dir.up do
        execute <<~SQL
        UPDATE devices SET
        online = ds.online,
        poweredon_at = ds.poweredon_at,
        devicetime = ds.devicetime,
        free_space = ds.free_space,
        now_playing = ds.now_playing
        FROM device_statuses ds WHERE devices.id = ds.device_id
        SQL
      end
      dir.down do
      end
    end
  end
end
