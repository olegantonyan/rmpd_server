class RemoveDepricatedColumnsFromPlaylistItems < ActiveRecord::Migration[6.0]
  def up
    remove_column :playlist_items, :show_duration
  end

  def down
  end
end
