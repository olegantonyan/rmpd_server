class RemoveDepricatedColumnsFromDevices < ActiveRecord::Migration[6.0]
  def up
    remove_column :devices, :wallpaper
    remove_column :devices, :message_queue_sync_period
  end

  def down
  end
end
