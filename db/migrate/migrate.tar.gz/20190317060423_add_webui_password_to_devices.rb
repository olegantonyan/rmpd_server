class AddWebuiPasswordToDevices < ActiveRecord::Migration[6.0]
  def change
    add_column :devices, :webui_password, :string, null: false, default: ''
  end
end
