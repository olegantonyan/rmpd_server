class DropDeviceStatuses < ActiveRecord::Migration[6.0]
  def up
    drop_table :device_statuses
  end

  def down
  end
end
